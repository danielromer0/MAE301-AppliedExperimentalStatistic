# Road Trip Planner

This Python script helps plan a road trip by finding the best route using Google Maps, determining if your car is gas or electric based on year, make, and model, and recommending stops for fuel or charging.

## Requirements

- Python 3.x
- googlemaps library
- requests library

Install dependencies:
```
pip install -r requirements.txt
```

## Setup

1. Get a Google Maps API key from [Google Cloud Console](https://console.cloud.google.com/).
2. Enable the Directions API, Places API, and Maps Static API for your project.
3. Replace `YOUR_GOOGLE_MAPS_API_KEY` in the script with your actual API key, or set the `GMAPS_API_KEY` environment variable.

4. (Optional) For accurate gas prices, get a free EIA API key from [EIA Open Data](https://www.eia.gov/opendata/register.php).
5. Set the `EIA_API_KEY` environment variable with your EIA API key.

6. (Optional) For accurate EV charging station information, get a free NREL API key from [NREL Developer Network](https://developer.nrel.gov/signup/). The station lookup endpoint used by the app now targets the current `developer.nlr.gov` API domain.
7. Set the `NREL_API_KEY` environment variable with your NREL API key.

Vehicle data now comes from FuelEconomy.gov only. When the XML API does not include a usable gas-vehicle range or tank size, the planner uses the official FuelEconomy vehicle page values for `Total Range` and `Tank Size` when available. If FuelEconomy publishes MPG and tank size but not total range, the planner derives range from those published values rather than using a local vehicle database.

## Usage

Run the script:
```
python roadtrip_planner.py
```

Enter the required information when prompted:
- Starting location
- Destination
- Car year
- Car make
- Car model

The script will output:
- Fuel type of your car
- Total distance and duration
- Recommended stops along the route

## Reproducing the Demo

To reproduce the demo with example data:

1. Ensure all dependencies are installed and API keys are configured as described in the Setup section.

2. Run the script:
   ```
   python roadtrip_planner.py
   ```

3. In the GUI interface, enter the following example inputs:
   - Starting location: New York, NY
   - Destination: Los Angeles, CA
   - Car year: 2020
   - Car make: Toyota
   - Car model: Prius

4. Click "Plan Trip" to generate the route. The application will display:
   - The total distance and estimated duration
   - Fuel type (gas or electric)
   - Recommended stops for fuel or charging
   - A static map of the route
   - A link to open the route in Google Maps

This demonstrates the core functionality of the road trip planner.

## Notes

- Fuel type is determined using the EPA Fuel Economy API and FuelEconomy.gov vehicle menus.
- Gas-vehicle range and tank size prefer the published FuelEconomy vehicle-page values because the XML API often omits those fields.
- Stops are recommended based on the vehicle's estimated range, not a fixed interval.
- Gas prices now use EIA's v2 series endpoint for official weekly averages, with the local gas price database used as a station-specific estimate when available.
- For electric vehicles, charging stations are found using the NREL API, and the app shows listed charging prices when NREL provides them.

## Limitations

- Requires Google Maps API key (not free for heavy usage).
- No live pump-price feed is integrated. Gas stations show EIA weekly averages plus local estimates where available, EV pricing depends on what the NREL station record includes, and some vehicle ranges may still fall back to generic defaults when FuelEconomy.gov does not publish enough data.
- Simple stop recommendation logic.
