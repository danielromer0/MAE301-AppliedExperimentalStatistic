import os
import re
import tempfile
from functools import lru_cache
from urllib.parse import quote, urlencode
import googlemaps
import requests
import tkinter as tk
from tkinter import ttk, scrolledtext
import webbrowser
from gas_price_database import lookup_gas_price
from vehicle_info import get_vehicle_info

# Note: You need to get your own Google Maps API key from https://console.cloud.google.com/
# Set it via environment variable GMAPS_API_KEY or replace the default string.
GMAPS_API_KEY = os.environ.get("GMAPS_API_KEY", "enter api key here")

# EIA API key for gas prices (free, register at https://www.eia.gov/opendata/register.php)
EIA_API_KEY = os.environ.get("EIA_API_KEY", "enter api key here")

EIA_SERIES_URL = "https://api.eia.gov/v2/seriesid"
EIA_NATIONAL_GAS_SERIES_ID = "PET.EMM_EPM0_PTE_NUS_DPG.W"
REQUEST_TIMEOUT_SECONDS = 20
REQUEST_HEADERS = {
    "User-Agent": "TripPlanner/1.0",
}

# State codes for EIA API
STATE_CODES = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
    'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
    'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
    'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
    'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
    'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
    'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
    'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
    'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY',
    'District of Columbia': 'DC'
}

# NREL API key for EV charging stations (free, register at https://developer.nrel.gov/signup/)
NREL_API_KEY = os.environ.get("NREL_API_KEY", "enter api key here")
NREL_NEAREST_URL = "https://developer.nlr.gov/api/alt-fuel-stations/v1/nearest.json"
DEFAULT_STOP_INTERVAL_METERS = 200000
EV_INITIAL_RANGE_FACTOR = 0.72
EV_RECURRING_RANGE_FACTOR = 0.58
EV_INITIAL_MAX_MILES = 240
EV_RECURRING_MAX_MILES = 200
EV_SEARCH_RADIUS_STEPS_METERS = (5000, 16093, 32187, 48280)

# Function to get route
def get_route(start, end):
    error_msg = ""
    if not GMAPS_API_KEY or GMAPS_API_KEY == "YOUR_GOOGLE_MAPS_API_KEY":
        error_msg = "Error: Google Maps API key is missing or not configured.\nSet the GMAPS_API_KEY environment variable or update GMAPS_API_KEY in the script."
        return None, None, None, None, None, error_msg

    try:
        gmaps = googlemaps.Client(key=GMAPS_API_KEY)
        directions = gmaps.directions(start, end, mode="driving")
    except ValueError as exc:
        error_msg = f"Google Maps API error: {exc}"
        return None, None, None, None, None, error_msg
    except Exception as exc:
        error_msg = f"Error fetching route: {exc}"
        return None, None, None, None, None, error_msg

    if directions:
        route = directions[0]
        distance = route['legs'][0]['distance']['text']
        duration = route['legs'][0]['duration']['text']
        steps = route['legs'][0]['steps']
        overview_polyline = route.get('overview_polyline', {}).get('points')
        bounds = route.get('bounds')
        return distance, duration, steps, overview_polyline, bounds, ""
    return None, None, None, None, None, "No route found."


def build_google_maps_link(start, end, waypoints=None):
    params = {
        "api": 1,
        "origin": start,
        "destination": end,
        "travelmode": "driving",
    }
    if waypoints:
        params["waypoints"] = "|".join(waypoints[:9])
    params = urlencode(params)
    return f"https://www.google.com/maps/dir/?{params}"


def build_static_map_url(start, end, waypoints=None, polyline=None, bounds=None, size="450x320"):
    if not GMAPS_API_KEY or GMAPS_API_KEY == "YOUR_GOOGLE_MAPS_API_KEY":
        return None

    params = [
        ("key", GMAPS_API_KEY),
        ("size", size),
        ("maptype", "roadmap"),
        ("format", "png"),
        ("scale", "2"),
    ]

    # Calculate center and zoom based on bounds if available
    if bounds:
        ne_lat = bounds['northeast']['lat']
        ne_lng = bounds['northeast']['lng']
        sw_lat = bounds['southwest']['lat']
        sw_lng = bounds['southwest']['lng']
        
        center_lat = (ne_lat + sw_lat) / 2
        center_lng = (ne_lng + sw_lng) / 2
        
        # Calculate zoom level based on bounds and map size
        lat_diff = abs(ne_lat - sw_lat)
        lng_diff = abs(ne_lng - sw_lng)
        
        # Use the larger dimension to determine zoom
        max_diff = max(lat_diff, lng_diff)
        
        # Rough calculation for zoom level (this is approximate)
        # For a 450x320 map, these are rough zoom levels - adjusted to zoom out more
        if max_diff > 10:  # Very large area
            zoom = 3
        elif max_diff > 5:  # Large area
            zoom = 4
        elif max_diff > 2:  # Medium area
            zoom = 5
        elif max_diff > 1:  # Small area
            zoom = 6
        elif max_diff > 0.5:  # Local area
            zoom = 7
        elif max_diff > 0.2:  # City area
            zoom = 8
        elif max_diff > 0.1:  # Town area
            zoom = 9
        else:  # Very local
            zoom = 10
            
        params.append(("center", f"{center_lat},{center_lng}"))
        params.append(("zoom", str(zoom)))
    else:
        # Fallback to fixed zoom if no bounds
        params.append(("zoom", "7"))

    markers = [
        f"color:green|label:S|{start}",
        f"color:red|label:D|{end}",
    ]
    if waypoints:
        for idx, waypoint in enumerate(waypoints[:7], start=1):
            markers.append(f"color:blue|label:{idx}|{waypoint}")

    for marker in markers:
        params.append(("markers", marker))

    if polyline:
        params.append(("path", f"color:0x0000ff|weight:4|enc:{polyline}"))
    else:
        path_points = [start]
        if waypoints:
            path_points.extend(waypoints[:7])
        path_points.append(end)
        params.append(("path", "color:0x0000ff|weight:4|" + "|".join(path_points)))

    request = requests.Request("GET", "https://maps.googleapis.com/maps/api/staticmap", params=params).prepare()
    return request.url


def fetch_map_image(url):
    try:
        response = requests.get(url, headers=REQUEST_HEADERS, timeout=15)
        if response.status_code == 200:
            return response.content
    except Exception:
        return None
    return None


def interpolate_step_location(step, distance_into_step_meters):
    step_distance = step.get("distance", {}).get("value", 0)
    start_location = step.get("start_location", {})
    end_location = step.get("end_location", {})

    if step_distance <= 0:
        return end_location.get("lat"), end_location.get("lng")

    fraction = max(0.0, min(1.0, distance_into_step_meters / step_distance))
    start_lat = start_location.get("lat", end_location.get("lat"))
    start_lng = start_location.get("lng", end_location.get("lng"))
    end_lat = end_location.get("lat", start_lat)
    end_lng = end_location.get("lng", start_lng)

    lat = start_lat + (end_lat - start_lat) * fraction
    lng = start_lng + (end_lng - start_lng) * fraction
    return lat, lng


def append_section(lines, title, section_lines):
    lines.append(title)
    lines.append("-" * len(title))
    lines.extend(section_lines)
    lines.append("")


def format_labeled_value(label, value, source=None):
    line = f"{label}: {value}"
    if source:
        line += f" ({source})"
    return line


def format_stop_lines(stop_entries):
    if not stop_entries:
        return ["No fuel or charging stops are recommended for this route based on the current estimated range."]

    lines = []
    for index, stop_entry in enumerate(stop_entries, start=1):
        mile_marker = stop_entry["mile_marker"]
        stations = stop_entry["stations"]
        best_station = stations[0]
        lines.append(f"Stop {index} - about {mile_marker:.0f} miles from start")
        lines.append(f"Best option: {best_station['name']}")
        lines.append(f"Address: {best_station['address']}")
        lines.append(f"Price: {best_station['price']}")

        if len(stations) > 1:
            nearby_bits = [
                f"{station['name']} ({station['price']})"
                for station in stations[1:4]
            ]
            lines.append("Nearby alternatives: " + " | ".join(nearby_bits))

        lines.append("")

    return lines[:-1]


def miles_to_meters(miles):
    return miles * 1609.34


def meters_to_miles(meters):
    return meters / 1609.34


def build_stop_plan(fuel_type, vehicle_range_miles):
    if vehicle_range_miles is None or vehicle_range_miles == 0:
        return {
            "first_leg_meters": DEFAULT_STOP_INTERVAL_METERS,
            "recurring_leg_meters": DEFAULT_STOP_INTERVAL_METERS,
            "summary_lines": [f"Recommended stop interval: {meters_to_miles(DEFAULT_STOP_INTERVAL_METERS):.0f} miles"],
        }

    if fuel_type == "electric":
        first_leg_miles = min(vehicle_range_miles * EV_INITIAL_RANGE_FACTOR, EV_INITIAL_MAX_MILES)
        recurring_leg_miles = min(vehicle_range_miles * EV_RECURRING_RANGE_FACTOR, EV_RECURRING_MAX_MILES)
        first_leg_meters = max(1, int(miles_to_meters(first_leg_miles)))
        recurring_leg_meters = max(1, int(miles_to_meters(recurring_leg_miles)))
        return {
            "first_leg_meters": first_leg_meters,
            "recurring_leg_meters": recurring_leg_meters,
            "summary_lines": [
                f"Recommended first charging leg: {first_leg_miles:.0f} miles",
                f"Recommended charging interval after that: {recurring_leg_miles:.0f} miles",
            ],
        }

    stop_interval = max(1, int(miles_to_meters(vehicle_range_miles * 0.8)))
    return {
        "first_leg_meters": stop_interval,
        "recurring_leg_meters": stop_interval,
        "summary_lines": [f"Recommended stop interval: {meters_to_miles(stop_interval):.0f} miles"],
    }


def ev_station_sort_key(station):
    dc_fast_count = station.get("dc_fast_count", 0) or 0
    level2_count = station.get("level2_count", 0) or 0
    network = (station.get("network") or "").lower()
    connector_types = [connector.upper() for connector in station.get("connector_types", [])]
    is_tesla_friendly = (
        "tesla" in network
        or "supercharger" in station.get("name", "").lower()
        or "NACS" in connector_types
        or "TESLA" in connector_types
    )
    distance_miles = station.get("distance_miles")
    if distance_miles is None:
        distance_miles = float("inf")

    return (
        0 if dc_fast_count > 0 else 1,
        0 if is_tesla_friendly else 1,
        distance_miles,
        0 if level2_count > 0 else 1,
        extract_price_value(station["price"]),
    )


def sort_stations_for_trip(stations, fuel_type):
    if fuel_type == "electric":
        return sorted(stations, key=ev_station_sort_key)
    return sorted(stations, key=lambda station: extract_price_value(station["price"]))


def extract_price_value(price_text):
    if not price_text:
        return float("inf")
    normalized_text = price_text.strip().lower()
    if normalized_text.startswith("free") or " free " in f" {normalized_text} ":
        return 0.0

    dollar_match = re.search(r"\$([0-9]+(?:\.[0-9]+)?)", price_text)
    if dollar_match:
        try:
            return float(dollar_match.group(1))
        except ValueError:
            return float("inf")

    cents_match = re.search("([0-9]+(?:\\.[0-9]+)?)\\s*(?:\\u00A2|cents?)", normalized_text)
    if cents_match:
        try:
            return float(cents_match.group(1)) / 100
        except ValueError:
            return float("inf")

    return float("inf")


def parse_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_eia_error_message(payload, fallback_message):
    if not isinstance(payload, dict):
        return fallback_message

    error = payload.get("error")
    if isinstance(error, dict):
        return error.get("message", fallback_message)
    if isinstance(error, str):
        return error
    return fallback_message


def _extract_numeric_value(record):
    if not isinstance(record, dict):
        return None

    for key in ("value", "price"):
        numeric_value = record.get(key)
        parsed = parse_float(numeric_value)
        if parsed is not None:
            return parsed

    for key, raw_value in record.items():
        if key == "period" or key.endswith("-units"):
            continue
        parsed = parse_float(raw_value)
        if parsed is not None:
            return parsed

    return None


def _parse_eia_series_payload(payload):
    response_data = payload.get("response", {}).get("data")
    if isinstance(response_data, list):
        for row in response_data:
            numeric_value = _extract_numeric_value(row)
            if numeric_value is not None:
                return numeric_value, row.get("period")

    series_list = payload.get("series")
    if isinstance(series_list, list):
        for series in series_list:
            series_data = series.get("data") if isinstance(series, dict) else None
            if not isinstance(series_data, list) or not series_data:
                continue
            first_row = series_data[0]
            if isinstance(first_row, (list, tuple)) and len(first_row) >= 2:
                numeric_value = parse_float(first_row[1])
                if numeric_value is not None:
                    return numeric_value, str(first_row[0])
            if isinstance(first_row, dict):
                numeric_value = _extract_numeric_value(first_row)
                if numeric_value is not None:
                    return numeric_value, first_row.get("period")

    return None, None


def _format_period_label(period):
    if not period:
        return None
    if re.fullmatch(r"\d{8}", str(period)):
        return f"{period[:4]}-{period[4:6]}-{period[6:]}"
    return str(period)


def _format_eia_gas_price(price, location_label, period):
    formatted_period = _format_period_label(period)
    if formatted_period:
        return f"${price:.3f} per gallon ({location_label} EIA weekly average, {formatted_period})"
    return f"${price:.3f} per gallon ({location_label} EIA weekly average)"


def _build_state_gas_series_id(state):
    state_code = STATE_CODES.get(state)
    if not state_code:
        return None
    return f"PET.EMM_EPM0_PTE_S{state_code}_DPG.W"


@lru_cache(maxsize=64)
def _fetch_eia_series_price(series_id):
    if not EIA_API_KEY or EIA_API_KEY == "YOUR_EIA_API_KEY":
        return None

    url = f"{EIA_SERIES_URL}/{quote(series_id, safe='')}"
    try:
        response = requests.get(
            url,
            params={"api_key": EIA_API_KEY},
            headers=REQUEST_HEADERS,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        payload = response.json()
    except requests.RequestException:
        return None
    except ValueError:
        return None

    if response.status_code != 200:
        return None

    if isinstance(payload, dict) and payload.get("error"):
        return None

    price, period = _parse_eia_series_payload(payload)
    if price is None:
        return None

    return {"price": price, "period": period}


@lru_cache(maxsize=64)
def _get_official_gas_price(state):
    series_candidates = []
    state_series_id = _build_state_gas_series_id(state) if state else None
    if state_series_id:
        series_candidates.append((state_series_id, state))
    series_candidates.append((EIA_NATIONAL_GAS_SERIES_ID, "U.S."))

    for series_id, location_label in series_candidates:
        series_data = _fetch_eia_series_price(series_id)
        if series_data:
            return _format_eia_gas_price(series_data["price"], location_label, series_data["period"])

    return None


def _combine_gas_price_sources(local_price, official_price):
    if local_price and official_price:
        if "brand average" in local_price.lower():
            return f"{official_price}; brand estimate {local_price}"
        return f"{local_price}; benchmark {official_price}"
    return local_price or official_price or "Gas price unavailable"


# Function to get gas prices from EIA API with local estimates as a station-specific fallback
def get_gas_price(state=None, station_name=None, address=None):
    local_price = lookup_gas_price(station_name, address)
    derived_state = state or extract_state_from_address(address or "")
    official_price = _get_official_gas_price(derived_state)
    return _combine_gas_price_sources(local_price, official_price)

# Function to extract state from address
def extract_state_from_address(address):
    # Simple extraction: look for state abbreviation in the address
    for state, code in STATE_CODES.items():
        if f", {code}" in address or f" {code} " in address:
            return state
    # If not found, try full state name
    for state in STATE_CODES:
        if state.lower() in address.lower():
            return state
    return None

# Function to find EV charging stations using NREL API
def find_ev_stations(location, radius=25):
    if not NREL_API_KEY or NREL_API_KEY == "YOUR_NREL_API_KEY":
        return []
    
    try:
        params = {
            "api_key": NREL_API_KEY,
            "access": "public",
            "fuel_type": "ELEC",
            "latitude": location[0],
            "longitude": location[1],
            "radius": radius,
            "status": "E",
            "limit": 5,
        }
        response = requests.get(
            NREL_NEAREST_URL,
            params=params,
            headers=REQUEST_HEADERS,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        data = response.json()
        if response.status_code != 200:
            message = _parse_eia_error_message(
                data,
                response.reason if hasattr(response, "reason") else "Unknown error",
            )
            print(f"Error fetching EV stations: HTTP {response.status_code}: {message}")
            return []

        stations = []
        if 'fuel_stations' in data:
            for station in data['fuel_stations']:
                name = station['station_name']
                address = station.get('street_address', 'Address not available')
                price = station.get('ev_pricing') or "Pricing not listed"
                network = station.get("ev_network")
                connectors = station.get("ev_connector_types") or []
                distance_miles = parse_float(station.get("distance"))
                dc_fast_count = station.get("ev_dc_fast_num") or 0
                level2_count = station.get("ev_level2_evse_num") or 0
                charger_bits = []
                if dc_fast_count:
                    charger_bits.append(f"{dc_fast_count} DC fast")
                if level2_count:
                    charger_bits.append(f"{level2_count} Level 2")
                if connectors:
                    charger_bits.append("/".join(connectors))
                if price == "Pricing not listed" and (network or charger_bits):
                    descriptor_bits = []
                    if network:
                        descriptor_bits.append(network)
                    descriptor_bits.extend(charger_bits)
                    price = f"Pricing not listed ({', '.join(descriptor_bits)})"
                stations.append(
                    {
                        'name': name,
                        'address': address,
                        'price': price,
                        'network': network,
                        'connector_types': connectors,
                        'distance_miles': distance_miles,
                        'dc_fast_count': dc_fast_count,
                        'level2_count': level2_count,
                    }
                )
        else:
            print("Warning: NREL returned no fuel_stations.")
        return stations
    except Exception as exc:
        print(f"Error fetching EV stations: {exc}")
        return []

# Function to find gas stations or charging stations
def find_stations(location, fuel_type, radius=5000):
    if fuel_type == "electric":
        # Parse location string to tuple
        lat, lng = map(float, location.split(','))
        search_radii = []
        for candidate_radius in EV_SEARCH_RADIUS_STEPS_METERS:
            search_radius = max(radius, candidate_radius)
            if search_radius not in search_radii:
                search_radii.append(search_radius)

        for search_radius in search_radii:
            stations = find_ev_stations((lat, lng), radius=search_radius / 1609.34)  # convert meters to miles
            if stations:
                return stations
        return []
    else:
        # For gas stations, use Google Places to find stations and EIA for state prices
        gmaps = googlemaps.Client(key=GMAPS_API_KEY)
        places = gmaps.places(query="gas station", location=location, radius=radius)
        stations = []
        if 'results' in places:
            for result in places['results']:
                name = result['name']
                address = result.get('formatted_address', 'Address not available')
                state = extract_state_from_address(address)
                price = get_gas_price(state=state, station_name=name, address=address)
                stations.append({'name': name, 'address': address, 'price': price})
                if len(stations) == 5:  # Limit to 5 stations
                    break
        return stations

# Main function
def plan_trip(start, end, year, make, model):
    report_lines = ["ROAD TRIP PLAN", ""]
    
    vehicle_data = get_vehicle_info(year, make, model)
    vehicle_lines = []
    if vehicle_data is None:
        vehicle_lines.append("Warning: Could not retrieve vehicle data from FuelEconomy.gov.")
        fuel_type = "gas"
        vehicle_range_miles = None
    else:
        fuel_type = vehicle_data["fuel_type"]
        vehicle_range_miles = vehicle_data["range_miles"]
        tank_size = vehicle_data.get("tank_size")
        tank_size_estimate = vehicle_data.get("tank_size_estimate")
        range_source = vehicle_data.get("range_source")
        tank_size_source = vehicle_data.get("tank_size_source")
        matched_make = vehicle_data.get("matched_make")
        matched_model = vehicle_data.get("matched_model")
        fuel_label = vehicle_data.get("fuel_label")
        source = vehicle_data.get("source", "unknown")
        if matched_make and matched_model:
            vehicle_lines.append(f"Matched vehicle: {matched_make} {matched_model}")
        vehicle_lines.append(f"Trip fuel type: {fuel_type}")
        vehicle_lines.append(f"Vehicle data source: {source}")
        if fuel_label:
            vehicle_lines.append(f"Fuel description: {fuel_label}")
        if vehicle_range_miles:
            vehicle_lines.append(
                format_labeled_value("Estimated range", f"{vehicle_range_miles:.0f} miles", range_source)
            )
        if tank_size:
            vehicle_lines.append(
                format_labeled_value("Tank size", f"{tank_size} gallons", tank_size_source)
            )
        elif tank_size_estimate:
            vehicle_lines.append(f"Estimated tank size: {tank_size_estimate:.1f} gallons")

    if fuel_type not in ("electric", "gas"):
        fuel_type = "gas"

    stop_plan = build_stop_plan(fuel_type, vehicle_range_miles)
    first_leg_meters = stop_plan["first_leg_meters"]
    recurring_leg_meters = stop_plan["recurring_leg_meters"]

    distance, duration, steps, overview_polyline, bounds, error_msg = get_route(start, end)
    if error_msg:
        append_section(report_lines, "Vehicle", vehicle_lines)
        append_section(report_lines, "Route", [error_msg])
        return "\n".join(report_lines).strip() + "\n", None, None, None
    if not distance:
        append_section(report_lines, "Vehicle", vehicle_lines)
        append_section(report_lines, "Route", ["Could not find route."])
        return "\n".join(report_lines).strip() + "\n", None, None, None

    route_lines = [
        f"From: {start}",
        f"To: {end}",
        f"Total distance: {distance}",
        f"Estimated drive time: {duration}",
    ]
    route_lines.extend(stop_plan["summary_lines"])

    stop_entries = []
    missing_stop_markers = []
    total_route_distance = sum(step['distance']['value'] for step in steps)
    cumulative_distance = 0
    next_stop_distance = first_leg_meters
    last_location = None
    recommended_waypoints = []
    for step in steps:
        step_distance = step['distance']['value']  # meters
        previous_cumulative_distance = cumulative_distance
        cumulative_distance += step_distance
        while next_stop_distance < total_route_distance and cumulative_distance >= next_stop_distance:
            distance_into_step = next_stop_distance - previous_cumulative_distance
            lat, lng = interpolate_step_location(step, distance_into_step)
            location = f"{lat:.6f},{lng:.6f}"
            if location != last_location:
                stations = find_stations(location, fuel_type)
                if stations:
                    stations = sort_stations_for_trip(stations, fuel_type)
                    stop_entries.append(
                        {
                            "mile_marker": meters_to_miles(next_stop_distance),
                            "stations": stations,
                        }
                    )
                    first_stop_address = stations[0]['address']
                    if first_stop_address not in recommended_waypoints:
                        recommended_waypoints.append(first_stop_address)
                else:
                    missing_stop_markers.append(meters_to_miles(next_stop_distance))
                last_location = location
            next_stop_distance += recurring_leg_meters

    maps_link = build_google_maps_link(start, end, recommended_waypoints)
    route_lines.append(f"Recommended stops found: {len(stop_entries)}")
    if missing_stop_markers:
        formatted_markers = ", ".join(f"{marker:.0f} mi" for marker in missing_stop_markers[:5])
        route_lines.append(f"Segments needing manual charger review: {formatted_markers}")
    navigation_lines = [f"Google Maps route link: {maps_link}"]
    if len(recommended_waypoints) > 9:
        navigation_lines.append(
            "Note: Google Maps only supports a limited number of waypoint stops, so only the first 9 were included in the link."
        )

    append_section(report_lines, "Vehicle", vehicle_lines)
    append_section(report_lines, "Route", route_lines)
    append_section(report_lines, "Recommended Stops", format_stop_lines(stop_entries))
    append_section(report_lines, "Navigation", navigation_lines)
    
    return "\n".join(report_lines).strip() + "\n", maps_link, overview_polyline, bounds

def main():
    print("Road Trip Planner")
    start = input("Enter starting location: ")
    end = input("Enter destination: ")
    year = input("Enter car year: ")
    make = input("Enter car make: ")
    model = input("Enter car model: ")
    
    result, _, _, _ = plan_trip(start, end, year, make, model)
    print(result)

def create_gui():
    root = tk.Tk()
    root.title("Road Trip Planner")
    root.geometry("1000x700")

    # Store the current map link
    map_link_var = tk.StringVar(value="")

    # === Input Frame (Top) ===
    input_frame = ttk.LabelFrame(root, text="Trip Details", padding=10)
    input_frame.pack(fill=tk.X, padx=10, pady=10)

    # First row
    ttk.Label(input_frame, text="Starting Location:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    start_entry = ttk.Entry(input_frame, width=30)
    start_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)

    ttk.Label(input_frame, text="Destination:").grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
    end_entry = ttk.Entry(input_frame, width=30)
    end_entry.grid(row=0, column=3, padx=5, pady=5, sticky=tk.EW)

    # Second row
    ttk.Label(input_frame, text="Car Year:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
    year_entry = ttk.Entry(input_frame, width=30)
    year_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)

    ttk.Label(input_frame, text="Car Make:").grid(row=1, column=2, padx=5, pady=5, sticky=tk.W)
    make_entry = ttk.Entry(input_frame, width=30)
    make_entry.grid(row=1, column=3, padx=5, pady=5, sticky=tk.EW)

    # Third row
    ttk.Label(input_frame, text="Car Model:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
    model_entry = ttk.Entry(input_frame, width=30)
    model_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)

    input_frame.columnconfigure(1, weight=1)
    input_frame.columnconfigure(3, weight=1)

    # === Main Content Frame (Bottom) - Two columns ===
    content_frame = ttk.Frame(root)
    content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # Left side - Output text (equal size)
    left_frame = ttk.LabelFrame(content_frame, text="Trip Results", padding=5)
    left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

    output_text = scrolledtext.ScrolledText(
        left_frame,
        width=50,
        height=40,
        wrap=tk.WORD,
        font=("Consolas", 10),
        padx=10,
        pady=10,
    )
    output_text.pack(fill=tk.BOTH, expand=True)
    output_text.config(state=tk.DISABLED)

    # Right side - Map section (equal size)
    right_frame = ttk.LabelFrame(content_frame, text="Map & Navigation", padding=10)
    right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

    # Map container frame
    map_container = ttk.Frame(right_frame)
    map_container.pack(fill=tk.X, pady=(0, 10))
    map_container.pack_propagate(False)
    map_container.configure(height=250)

    # Map preview label
    map_image_label = tk.Label(map_container, text="Map will appear here", anchor=tk.CENTER, background="#f0f0f0", relief=tk.SOLID)
    map_image_label.pack(fill=tk.BOTH, expand=True)

    map_photo = None

    # Status label
    status_label = tk.Label(right_frame, text="Plan your trip to\ngenerate the map", 
                            font=("Arial", 10), justify=tk.CENTER, fg="gray")
    status_label.pack(pady=(0, 10))

    # Open in Maps button
    def open_map():
        link = map_link_var.get()
        if link:
            webbrowser.open(link)
        else:
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, "\n[Info] Plan your trip first to generate a map link.\n")
            output_text.config(state=tk.DISABLED)

    # Plan function
    def plan():
        start = start_entry.get()
        end = end_entry.get()
        year = year_entry.get()
        make = make_entry.get()
        model = model_entry.get()

        if not all([start, end, year, make, model]):
            output_text.config(state=tk.NORMAL)
            output_text.delete(1.0, tk.END)
            output_text.insert(tk.END, "Please fill in all fields before planning your trip.")
            output_text.config(state=tk.DISABLED)
            status_label.config(text="Warning: Missing fields", fg="red")
            return

        status_label.config(text="Planning...", fg="orange")
        root.update()

        result, maps_link, route_polyline, route_bounds = plan_trip(start, end, year, make, model)
        output_text.config(state=tk.NORMAL)
        output_text.delete(1.0, tk.END)
        output_text.insert(tk.END, result)
        output_text.config(state=tk.DISABLED)

        if maps_link:
            map_link_var.set(maps_link)

            static_url = build_static_map_url(start, end, polyline=route_polyline, bounds=route_bounds)
            map_image_data = fetch_map_image(static_url) if static_url else None
            if map_image_data:
                try:
                    fd, temp_path = tempfile.mkstemp(suffix='.png')
                    os.close(fd)
                    with open(temp_path, 'wb') as f:
                        f.write(map_image_data)
                    map_photo_obj = tk.PhotoImage(file=temp_path)
                    map_image_label.configure(image=map_photo_obj, text="")
                    map_image_label.image = map_photo_obj
                    map_photo = map_photo_obj
                    os.remove(temp_path)
                except Exception:
                    map_image_label.configure(text="Could not load map preview")
            else:
                map_image_label.configure(text="Map preview unavailable")

            status_label.config(text="Route ready!", fg="green")
        else:
            map_image_label.configure(text="Map preview unavailable")
            status_label.config(text="Warning: No route found", fg="red")

    map_button = ttk.Button(right_frame, text="Open in Google Maps", command=open_map)
    map_button.pack(pady=(0, 10), fill=tk.X)

    # Plan button (bottom of right frame)
    plan_button = ttk.Button(right_frame, text="Plan Trip", command=plan)
    plan_button.pack(fill=tk.X)

    root.mainloop()

if __name__ == "__main__":
    create_gui()
