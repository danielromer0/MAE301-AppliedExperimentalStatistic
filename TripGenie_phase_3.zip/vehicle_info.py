import re
import xml.etree.ElementTree as ET
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from functools import lru_cache
from statistics import median

import requests

BASE_URL = "https://www.fueleconomy.gov/ws/rest"
SUMMARY_PAGE_URL = "https://www.fueleconomy.gov/feg/Find.do"
REQUEST_TIMEOUT_SECONDS = 15
REQUEST_HEADERS = {
    "User-Agent": "TripPlanner/1.0",
}


def parse_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _normalize_lookup_text(value):
    if not value:
        return ""
    return re.sub(r"[^a-z0-9]+", "", value.strip().lower())


def _summary_page_text(html):
    text = re.sub(r"<[^>]+>", " ", html)
    return re.sub(r"\s+", " ", text)


def _extract_summary_page_range(html):
    text = _summary_page_text(html)
    match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*miles\s*Total\s*Range", text, flags=re.IGNORECASE)
    if not match:
        return None
    return parse_float(match.group(1))


def _extract_summary_page_tank_size(html):
    text = _summary_page_text(html)
    match = re.search(r"Tank\s*Size\s*([0-9]+(?:\.[0-9]+)?)\s*gallons", text, flags=re.IGNORECASE)
    if not match:
        return None
    return parse_float(match.group(1))


def _median_or_none(values):
    if not values:
        return None
    return float(median(values))


def _first_positive_float(*values):
    for value in values:
        parsed = parse_float(value)
        if parsed is not None and parsed > 0:
            return parsed
    return None


def _most_common_non_empty(values):
    filtered = [value for value in values if value]
    if not filtered:
        return None
    return Counter(filtered).most_common(1)[0][0]


def _build_menu_params(year="", make="", model=""):
    params = {}
    if year:
        params["year"] = str(year).strip()
    if make:
        params["make"] = str(make).strip()
    if model:
        params["model"] = str(model).strip()
    return params


@lru_cache(maxsize=128)
def _get_menu_items(menu_name, year="", make="", model=""):
    url = f"{BASE_URL}/vehicle/menu/{menu_name}"
    response = requests.get(
        url,
        params=_build_menu_params(year=year, make=make, model=model),
        headers=REQUEST_HEADERS,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    root = ET.fromstring(response.text)

    items = []
    for item in root.findall(".//menuItem"):
        text = item.findtext("text")
        value = item.findtext("value")
        if text and value:
            items.append({"text": text, "value": value})
    return tuple((item["text"], item["value"]) for item in items)


def _score_menu_item(requested_text, text, value):
    requested = _normalize_lookup_text(requested_text)
    text_normalized = _normalize_lookup_text(text)
    value_normalized = _normalize_lookup_text(value)
    candidates = [text_normalized, value_normalized]

    if requested in candidates:
        return 4.0
    if any(candidate.startswith(requested) for candidate in candidates):
        return 3.0 - min(len(candidate) - len(requested) for candidate in candidates if candidate.startswith(requested)) / 1000.0
    if any(requested in candidate for candidate in candidates):
        return 2.0 - min(len(candidate) - len(requested) for candidate in candidates if requested in candidate) / 1000.0

    return max(SequenceMatcher(None, requested, candidate).ratio() for candidate in candidates)


def _resolve_menu_value(requested_text, menu_name, year="", make="", model=""):
    raw_items = _get_menu_items(menu_name, year=year, make=make, model=model)
    items = [{"text": text, "value": value} for text, value in raw_items]
    if not items:
        return None

    requested = _normalize_lookup_text(requested_text)
    if not requested:
        return items[0]

    scored_items = [
        (_score_menu_item(requested_text, item["text"], item["value"]), item)
        for item in items
    ]
    best_score, best_item = max(scored_items, key=lambda pair: pair[0])
    if best_score < 0.55:
        return None
    return best_item


def _resolve_model_items(requested_text, year="", make=""):
    raw_items = _get_menu_items("model", year=year, make=make)
    items = [{"text": text, "value": value} for text, value in raw_items]
    if not items:
        return []

    requested = _normalize_lookup_text(requested_text)
    if not requested:
        return [items[0]]

    exact_matches = [
        item
        for item in items
        if requested in (_normalize_lookup_text(item["text"]), _normalize_lookup_text(item["value"]))
    ]
    if exact_matches:
        best_exact = min(exact_matches, key=lambda item: len(_normalize_lookup_text(item["text"])))
        return [best_exact]

    prefix_matches = [
        item
        for item in items
        if _normalize_lookup_text(item["text"]).startswith(requested)
        or _normalize_lookup_text(item["value"]).startswith(requested)
    ]
    if prefix_matches:
        return sorted(prefix_matches, key=lambda item: len(_normalize_lookup_text(item["text"])))

    contains_matches = [
        item
        for item in items
        if requested in _normalize_lookup_text(item["text"])
        or requested in _normalize_lookup_text(item["value"])
    ]
    if contains_matches:
        return sorted(contains_matches, key=lambda item: len(_normalize_lookup_text(item["text"])))

    best_item = _resolve_menu_value(requested_text, "model", year=year, make=make)
    return [best_item] if best_item else []


@lru_cache(maxsize=256)
def _get_vehicle_root(vehicle_id):
    url = f"{BASE_URL}/vehicle/{vehicle_id}"
    response = requests.get(
        url,
        headers=REQUEST_HEADERS,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    return ET.fromstring(response.text)


@lru_cache(maxsize=256)
def _get_vehicle_summary_metrics(vehicle_id):
    response = requests.get(
        SUMMARY_PAGE_URL,
        params={"action": "sbs", "id": vehicle_id},
        headers=REQUEST_HEADERS,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    html = response.text
    return {
        "range_miles": _extract_summary_page_range(html),
        "tank_size": _extract_summary_page_tank_size(html),
    }


def _normalize_trip_fuel_type(root):
    fuel_type = (root.findtext("fuelType") or "").lower()
    fuel_type1 = (root.findtext("fuelType1") or "").lower()
    fuel_type2 = (root.findtext("fuelType2") or "").lower()
    atv_type = (root.findtext("atvType") or "").lower()

    electricity_primary = "electricity" in fuel_type1 or atv_type == "ev"
    gas_primary = any(term in fuel_type1 for term in ("gasoline", "diesel", "regular", "premium", "midgrade"))
    electricity_secondary = "electricity" in fuel_type2

    if electricity_primary and not gas_primary:
        return "electric"
    if electricity_secondary and gas_primary:
        # Plug-in hybrids can still road-trip on gasoline, which makes gas stops the safer default.
        return "gas"
    if "electricity" in fuel_type or atv_type == "ev":
        return "electric"
    return "gas"


def _extract_vehicle_profile(vehicle_id):
    root = _get_vehicle_root(vehicle_id)
    trip_fuel_type = _normalize_trip_fuel_type(root)
    api_range = None

    if trip_fuel_type == "electric":
        api_range = _first_positive_float(
            root.findtext("range"),
            root.findtext("rangeA"),
            root.findtext("rangeCityA"),
            root.findtext("rangeHwyA"),
            root.findtext("rangeCity"),
            root.findtext("rangeHwy"),
        )
    else:
        api_range = _first_positive_float(
            root.findtext("range"),
            root.findtext("rangeCity"),
            root.findtext("rangeHwy"),
        )

    gas_mpg = _first_positive_float(
        root.findtext("comb08"),
        root.findtext("highway08"),
        root.findtext("city08"),
    )
    official_tank_size = _first_positive_float(
        root.findtext("tankSize"),
        root.findtext("fuelTankSize"),
    )

    page_range = None
    page_tank_size = None
    if trip_fuel_type == "gas" or api_range is None:
        page_metrics = _get_vehicle_summary_metrics(vehicle_id)
        page_range = page_metrics["range_miles"]
        page_tank_size = page_metrics["tank_size"]

    if trip_fuel_type == "gas":
        range_miles = page_range or api_range
    else:
        range_miles = api_range or page_range

    tank_size = official_tank_size or page_tank_size
    range_source = None
    if trip_fuel_type == "gas" and page_range is not None:
        range_source = "FuelEconomy.gov vehicle page"
    elif api_range is not None:
        range_source = "FuelEconomy.gov API"
    elif page_range is not None:
        range_source = "FuelEconomy.gov vehicle page"

    tank_size_source = None
    if official_tank_size is not None:
        tank_size_source = "FuelEconomy.gov API"
    elif page_tank_size is not None:
        tank_size_source = "FuelEconomy.gov vehicle page"

    return {
        "vehicle_id": vehicle_id,
        "trip_fuel_type": trip_fuel_type,
        "fuel_label": root.findtext("fuelType") or root.findtext("fuelType1"),
        "model_label": root.findtext("model"),
        "vclass": root.findtext("VClass"),
        "range_miles": range_miles,
        "range_source": range_source,
        "gas_mpg": gas_mpg,
        "tank_size": tank_size,
        "tank_size_source": tank_size_source,
    }


def _build_vehicle_result(profiles, matched_make, matched_model):
    if not profiles:
        return None

    fuel_type = _most_common_non_empty([profile["trip_fuel_type"] for profile in profiles]) or "gas"
    fuel_label = _most_common_non_empty([profile["fuel_label"] for profile in profiles])
    official_ranges = [profile["range_miles"] for profile in profiles if profile["range_miles"]]
    official_tank_sizes = [profile["tank_size"] for profile in profiles if profile["tank_size"]]
    gas_mpg_values = [profile["gas_mpg"] for profile in profiles if profile["gas_mpg"]]
    range_source = _most_common_non_empty([profile["range_source"] for profile in profiles])
    tank_size_source = _most_common_non_empty([profile["tank_size_source"] for profile in profiles])

    range_miles = _median_or_none(official_ranges)
    tank_size = _median_or_none(official_tank_sizes)
    tank_size_estimate = None
    source = "FuelEconomy.gov"

    if range_miles is None and fuel_type == "gas":
        gas_mpg = _median_or_none(gas_mpg_values)
        if gas_mpg is not None and tank_size is not None:
            range_miles = gas_mpg * tank_size
            range_source = "Derived from FuelEconomy MPG and tank size"
            source = "FuelEconomy-derived"

    if range_miles is None:
        range_miles = 300.0 if fuel_type == "electric" else 400.0
        range_source = "Generic fallback"
        source = "default"

    return {
        "vehicle_id": ",".join(profile["vehicle_id"] for profile in profiles),
        "fuel_type": fuel_type,
        "fuel_label": fuel_label,
        "range_miles": range_miles,
        "range_source": range_source,
        "tank_size": tank_size,
        "tank_size_source": tank_size_source,
        "tank_size_estimate": tank_size_estimate,
        "source": source,
        "matched_make": matched_make,
        "matched_model": matched_model,
    }


def find_vehicle_ids(year, make, model):
    matched_make = _resolve_menu_value(make, "make", year=year)
    if not matched_make:
        return None, None, []

    matched_models = _resolve_model_items(
        model,
        year=year,
        make=matched_make["value"],
    )
    if not matched_models:
        return matched_make["text"], None, []

    matched_model_labels = [item["text"] for item in matched_models]
    matched_model_display = matched_model_labels[0]
    if len(matched_model_labels) > 1:
        matched_model_display = f"{model} ({len(matched_model_labels)} EPA variants)"

    vehicle_ids = []
    def fetch_option_items(model_item):
        return _get_menu_items(
            "options",
            year=year,
            make=matched_make["value"],
            model=model_item["value"],
        )

    if len(matched_models) > 4:
        max_workers = min(8, len(matched_models))
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            option_groups = list(executor.map(fetch_option_items, matched_models))
    else:
        option_groups = [fetch_option_items(matched_model) for matched_model in matched_models]

    for option_items in option_groups:
        for _, value in option_items:
            if value and value not in vehicle_ids:
                vehicle_ids.append(value)

    return matched_make["text"], matched_model_display, vehicle_ids


def get_vehicle_info(year, make, model):
    print(f"Retrieving vehicle info for {year} {make} {model}...")

    matched_make, matched_model, vehicle_ids = find_vehicle_ids(year, make, model)
    if not vehicle_ids:
        print("No matching vehicle found in FuelEconomy.gov.")
        return None

    print(f"Matched EPA vehicle selection: make={matched_make}, model={matched_model}, options={len(vehicle_ids)}")
    if len(vehicle_ids) > 4:
        max_workers = min(8, len(vehicle_ids))
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            profiles = list(executor.map(_extract_vehicle_profile, vehicle_ids))
    else:
        profiles = [_extract_vehicle_profile(vehicle_id) for vehicle_id in vehicle_ids]
    result = _build_vehicle_result(profiles, matched_make, matched_model)

    if result is None:
        print("Could not build a vehicle profile from EPA data.")
        return None

    print(
        "EPA vehicle data:",
        f"fuel_type={result['fuel_type']},",
        f"range_miles={result['range_miles']},",
        f"tank_size={result['tank_size']},",
        f"source={result['source']}",
    )
    return result
