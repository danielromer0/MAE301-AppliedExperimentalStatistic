import sys
import types
import unittest
from unittest.mock import patch


try:
    import googlemaps  # noqa: F401
except ImportError:
    sys.modules["googlemaps"] = types.SimpleNamespace(Client=lambda *args, **kwargs: None)

import roadtrip_planner


class MockResponse:
    def __init__(self, status_code=200, payload=None, reason="OK"):
        self.status_code = status_code
        self._payload = payload if payload is not None else {}
        self.reason = reason

    def json(self):
        return self._payload


class PriceLookupTests(unittest.TestCase):
    def setUp(self):
        roadtrip_planner._fetch_eia_series_price.cache_clear()
        roadtrip_planner._get_official_gas_price.cache_clear()
        self.original_eia_key = roadtrip_planner.EIA_API_KEY
        self.original_nrel_key = roadtrip_planner.NREL_API_KEY
        roadtrip_planner.EIA_API_KEY = "test-eia-key"
        roadtrip_planner.NREL_API_KEY = "test-nrel-key"

    def tearDown(self):
        roadtrip_planner.EIA_API_KEY = self.original_eia_key
        roadtrip_planner.NREL_API_KEY = self.original_nrel_key
        roadtrip_planner._fetch_eia_series_price.cache_clear()
        roadtrip_planner._get_official_gas_price.cache_clear()

    def test_get_gas_price_combines_local_estimate_with_official_benchmark(self):
        response = MockResponse(
            payload={
                "response": {
                    "data": [
                        {"period": "2026-04-20", "value": "4.044"},
                    ]
                }
            }
        )

        with patch("roadtrip_planner.requests.get", return_value=response) as mock_get:
            price = roadtrip_planner.get_gas_price(
                station_name="Shell",
                address="123 Main St, Phoenix, AZ 85001, USA",
            )

        self.assertIn("$3.99 per gallon (local city/brand estimate)", price)
        self.assertIn("$4.044 per gallon (Arizona EIA weekly average, 2026-04-20)", price)
        self.assertIn("PET.EMM_EPM0_PTE_SAZ_DPG.W", mock_get.call_args.args[0])

    def test_get_gas_price_falls_back_to_national_average_when_state_series_is_missing(self):
        responses = [
            MockResponse(status_code=404, payload={"error": {"message": "Not found"}}, reason="Not Found"),
            MockResponse(
                payload={
                    "response": {
                        "data": [
                            {"period": "2026-04-20", "value": "4.044"},
                        ]
                    }
                }
            ),
        ]

        with patch("roadtrip_planner.requests.get", side_effect=responses) as mock_get:
            price = roadtrip_planner.get_gas_price(
                state="Arizona",
                station_name="Roadside Fuel",
                address="500 Route 66, Winslow, AZ 86047, USA",
            )

        self.assertEqual(price, "$4.044 per gallon (U.S. EIA weekly average, 2026-04-20)")
        self.assertEqual(mock_get.call_count, 2)

    def test_extract_price_value_handles_free_and_cents_formats(self):
        self.assertEqual(roadtrip_planner.extract_price_value("Free for customers"), 0.0)
        self.assertAlmostEqual(
            roadtrip_planner.extract_price_value("31 cents per kWh"),
            0.31,
            places=2,
        )
        self.assertAlmostEqual(
            roadtrip_planner.extract_price_value("Pricing not listed ($0.49/kWh)"),
            0.49,
            places=2,
        )

    def test_find_ev_stations_uses_nlr_endpoint_and_preserves_miles_radius(self):
        captured = {}

        def fake_get(url, params=None, headers=None, timeout=None):
            captured["url"] = url
            captured["params"] = params
            return MockResponse(
                payload={
                    "fuel_stations": [
                        {
                            "station_name": "Test DC Fast",
                            "street_address": "1 Main St",
                            "ev_network": "EVgo",
                            "ev_dc_fast_num": 4,
                            "ev_connector_types": ["J1772COMBO"],
                            "ev_pricing": None,
                        }
                    ]
                }
            )

        with patch("roadtrip_planner.requests.get", side_effect=fake_get):
            stations = roadtrip_planner.find_ev_stations((33.4484, -112.0740), radius=5)

        self.assertEqual(captured["url"], roadtrip_planner.NREL_NEAREST_URL)
        self.assertEqual(captured["params"]["radius"], 5)
        self.assertEqual(
            stations[0]["price"],
            "Pricing not listed (EVgo, 4 DC fast, J1772COMBO)",
        )

    def test_find_stations_converts_meters_to_miles_for_ev_queries(self):
        with patch("roadtrip_planner.find_ev_stations", return_value=[{"name": "Station", "address": "A", "price": "Pricing not listed"}]) as mock_find_ev:
            roadtrip_planner.find_stations("33.4484,-112.0740", "electric", radius=8046.7)

        called_args, called_kwargs = mock_find_ev.call_args
        self.assertEqual(called_args[0], (33.4484, -112.0740))
        self.assertAlmostEqual(called_kwargs["radius"], 5.0, places=2)

    def test_find_stations_expands_ev_search_radius_when_nearby_search_is_empty(self):
        call_radii = []

        def fake_find_ev(location, radius=25):
            call_radii.append(radius)
            if len(call_radii) == 3:
                return [{"name": "Farther Station", "address": "A", "price": "Pricing not listed"}]
            return []

        with patch("roadtrip_planner.find_ev_stations", side_effect=fake_find_ev):
            stations = roadtrip_planner.find_stations("33.4484,-112.0740", "electric", radius=5000)

        self.assertEqual(stations[0]["name"], "Farther Station")
        self.assertAlmostEqual(call_radii[0], 5000 / 1609.34, places=2)
        self.assertAlmostEqual(call_radii[1], 16093 / 1609.34, places=2)
        self.assertAlmostEqual(call_radii[2], 32187 / 1609.34, places=2)


class RouteStopTests(unittest.TestCase):
    def _vehicle_data(self, range_miles):
        return {
            "fuel_type": "gas",
            "range_miles": range_miles,
            "tank_size": None,
            "tank_size_estimate": 15.0,
            "matched_make": "Test",
            "matched_model": "Route Car",
            "fuel_label": "Regular Gasoline",
            "source": "EPA-estimated",
        }

    def _ev_vehicle_data(self, range_miles):
        return {
            "fuel_type": "electric",
            "range_miles": range_miles,
            "tank_size": None,
            "tank_size_estimate": None,
            "matched_make": "Tesla",
            "matched_model": "Model 3",
            "fuel_label": "Electricity",
            "source": "FuelEconomy.gov",
        }

    def test_plan_trip_interpolates_stop_locations_within_long_steps(self):
        vehicle_range_miles = 100.0
        stop_interval = int(vehicle_range_miles * 1609.34 * 0.8)
        step_distance = stop_interval + 5000
        first_fraction = stop_interval / step_distance
        second_fraction = (2 * stop_interval - step_distance) / step_distance
        expected_locations = [
            f"{0.0:.6f},{first_fraction:.6f}",
            f"{0.0:.6f},{1 + second_fraction:.6f}",
        ]
        seen_locations = []

        steps = [
            {
                "distance": {"value": step_distance},
                "start_location": {"lat": 0.0, "lng": 0.0},
                "end_location": {"lat": 0.0, "lng": 1.0},
            },
            {
                "distance": {"value": step_distance},
                "start_location": {"lat": 0.0, "lng": 1.0},
                "end_location": {"lat": 0.0, "lng": 2.0},
            },
        ]

        def fake_find_stations(location, fuel_type, radius=5000):
            seen_locations.append(location)
            return [
                {
                    "name": f"Stop at {location}",
                    "address": f"{location} Address",
                    "price": "$3.50 per gallon",
                }
            ]

        with patch("roadtrip_planner.get_vehicle_info", return_value=self._vehicle_data(vehicle_range_miles)), \
             patch("roadtrip_planner.get_route", return_value=("170 mi", "3 hours", steps, None, None, "")), \
             patch("roadtrip_planner.find_stations", side_effect=fake_find_stations), \
             patch("roadtrip_planner.build_google_maps_link", return_value="https://maps.test"):
            result, _, _, _ = roadtrip_planner.plan_trip("A", "B", "2024", "Test", "Route Car")

        self.assertEqual(seen_locations, expected_locations)
        self.assertIn("Recommended Stops", result)
        self.assertIn("Stop 1 - about 80 miles from start", result)
        self.assertIn("Stop 2 - about 160 miles from start", result)

    def test_plan_trip_keeps_multiple_stops_that_fall_inside_one_step(self):
        vehicle_range_miles = 50.0
        stop_interval = int(vehicle_range_miles * 1609.34 * 0.8)
        step_distance = (stop_interval * 2) + 10000
        first_fraction = stop_interval / step_distance
        second_fraction = (2 * stop_interval) / step_distance
        expected_locations = [
            f"{0.0:.6f},{first_fraction:.6f}",
            f"{0.0:.6f},{second_fraction:.6f}",
        ]
        seen_locations = []

        steps = [
            {
                "distance": {"value": step_distance},
                "start_location": {"lat": 0.0, "lng": 0.0},
                "end_location": {"lat": 0.0, "lng": 1.0},
            }
        ]

        def fake_find_stations(location, fuel_type, radius=5000):
            seen_locations.append(location)
            return [
                {
                    "name": f"Stop at {location}",
                    "address": f"{location} Address",
                    "price": "$3.50 per gallon",
                }
            ]

        with patch("roadtrip_planner.get_vehicle_info", return_value=self._vehicle_data(vehicle_range_miles)), \
             patch("roadtrip_planner.get_route", return_value=("86 mi", "2 hours", steps, None, None, "")), \
             patch("roadtrip_planner.find_stations", side_effect=fake_find_stations), \
             patch("roadtrip_planner.build_google_maps_link", return_value="https://maps.test"):
            result, _, _, _ = roadtrip_planner.plan_trip("A", "B", "2024", "Test", "Route Car")

        self.assertEqual(seen_locations, expected_locations)
        self.assertEqual(len(seen_locations), 2)
        self.assertIn("Stop 1 - about 40 miles from start", result)
        self.assertIn("Stop 2 - about 80 miles from start", result)

    def test_plan_trip_uses_more_conservative_stop_spacing_for_evs(self):
        vehicle_range_miles = 300.0
        first_leg_meters = int(vehicle_range_miles * 1609.34 * 0.72)
        recurring_leg_meters = int(vehicle_range_miles * 1609.34 * 0.58)
        route_distance = first_leg_meters + (2 * recurring_leg_meters) + 10000
        seen_locations = []

        steps = [
            {
                "distance": {"value": route_distance},
                "start_location": {"lat": 0.0, "lng": 0.0},
                "end_location": {"lat": 0.0, "lng": 3.0},
            }
        ]

        def fake_find_stations(location, fuel_type, radius=5000):
            seen_locations.append(location)
            return [
                {
                    "name": "Tesla Supercharger",
                    "address": f"{location} Address",
                    "price": "Pricing not listed (Tesla Supercharger, 12 DC fast, NACS)",
                    "network": "Tesla",
                    "connector_types": ["NACS"],
                    "distance_miles": 1.2,
                    "dc_fast_count": 12,
                    "level2_count": 0,
                }
            ]

        with patch("roadtrip_planner.get_vehicle_info", return_value=self._ev_vehicle_data(vehicle_range_miles)), \
             patch("roadtrip_planner.get_route", return_value=("360 mi", "6 hours", steps, None, None, "")), \
             patch("roadtrip_planner.find_stations", side_effect=fake_find_stations), \
             patch("roadtrip_planner.build_google_maps_link", return_value="https://maps.test"):
            result, _, _, _ = roadtrip_planner.plan_trip("A", "B", "2024", "Tesla", "Model 3")

        self.assertEqual(len(seen_locations), 3)
        self.assertIn("Recommended first charging leg: 216 miles", result)
        self.assertIn("Recommended charging interval after that: 174 miles", result)
        self.assertIn("Stop 1 - about 216 miles from start", result)
        self.assertIn("Stop 2 - about 390 miles from start", result)


if __name__ == "__main__":
    unittest.main()
