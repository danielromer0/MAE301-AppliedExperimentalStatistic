import unittest
from unittest.mock import patch

import vehicle_info


class MockResponse:
    def __init__(self, text, status_code=200):
        self.text = text
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def menu_xml(items):
    inner = "".join(
        f"<menuItem><text>{text}</text><value>{value}</value></menuItem>"
        for text, value in items
    )
    return f'<?xml version="1.0" encoding="UTF-8"?><menuItems>{inner}</menuItems>'


def vehicle_xml(**fields):
    inner = "".join(f"<{key}>{value}</{key}>" for key, value in fields.items())
    return f'<?xml version="1.0" encoding="UTF-8"?><vehicle>{inner}</vehicle>'


def sbs_html(total_range=None, tank_size=None):
    range_html = ""
    if total_range is not None:
        range_html = f'<td class="sbsCellData">{total_range} milesTotal Range</td>'

    tank_row = ""
    if tank_size is not None:
        tank_row = f"<tr><th scope=\"row\">Tank Size</th><td>{tank_size} gallons</td></tr>"

    return f"<html><body>{range_html}<table>{tank_row}</table></body></html>"


class VehicleInfoTests(unittest.TestCase):
    def setUp(self):
        vehicle_info._get_menu_items.cache_clear()
        vehicle_info._get_vehicle_root.cache_clear()
        vehicle_info._get_vehicle_summary_metrics.cache_clear()

    def tearDown(self):
        vehicle_info._get_menu_items.cache_clear()
        vehicle_info._get_vehicle_root.cache_clear()
        vehicle_info._get_vehicle_summary_metrics.cache_clear()

    def test_gas_vehicle_uses_official_summary_page_range_and_tank_size(self):
        def fake_get(url, params=None, headers=None, timeout=None):
            if url.endswith("/vehicle/menu/make"):
                return MockResponse(menu_xml([("Toyota", "Toyota"), ("Honda", "Honda")]))
            if url.endswith("/vehicle/menu/model"):
                self.assertEqual(params["make"], "Toyota")
                return MockResponse(menu_xml([("Camry", "Camry"), ("Camry Hybrid LE", "Camry Hybrid LE")]))
            if url.endswith("/vehicle/menu/options"):
                self.assertEqual(params["model"], "Camry")
                return MockResponse(
                    menu_xml(
                        [
                            ("Auto (S8), 4 cyl, 2.5 L", "47085"),
                            ("Auto (S8), 4 cyl, 2.5 L, AWD", "47086"),
                        ]
                    )
                )
            if url.endswith("/vehicle/47085"):
                return MockResponse(
                    vehicle_xml(
                        fuelType="Regular",
                        fuelType1="Regular Gasoline",
                        fuelType2="",
                        range="0",
                        rangeCity="0.0",
                        rangeHwy="0.0",
                        comb08="32",
                        VClass="Midsize Cars",
                        model="Camry",
                    )
                )
            if url.endswith("/vehicle/47086"):
                return MockResponse(
                    vehicle_xml(
                        fuelType="Regular",
                        fuelType1="Regular Gasoline",
                        fuelType2="",
                        range="0",
                        rangeCity="0.0",
                        rangeHwy="0.0",
                        comb08="30",
                        VClass="Midsize Cars",
                        model="Camry",
                    )
                )
            if "Find.do" in url:
                return MockResponse(sbs_html(total_range=411, tank_size=15.8))
            raise AssertionError(f"Unexpected URL {url}")

        with patch("vehicle_info.requests.get", side_effect=fake_get):
            result = vehicle_info.get_vehicle_info("2024", "Toyta", "camry")

        self.assertEqual(result["fuel_type"], "gas")
        self.assertEqual(result["matched_make"], "Toyota")
        self.assertEqual(result["matched_model"], "Camry")
        self.assertEqual(result["source"], "FuelEconomy.gov")
        self.assertEqual(result["range_source"], "FuelEconomy.gov vehicle page")
        self.assertEqual(result["tank_size_source"], "FuelEconomy.gov vehicle page")
        self.assertIsNone(result["tank_size_estimate"])
        self.assertAlmostEqual(result["tank_size"], 15.8, places=1)
        self.assertAlmostEqual(result["range_miles"], 411.0, places=1)

    def test_phev_uses_official_total_range_and_gas_trip_type(self):
        def fake_get(url, params=None, headers=None, timeout=None):
            if url.endswith("/vehicle/menu/make"):
                return MockResponse(menu_xml([("Toyota", "Toyota")]))
            if url.endswith("/vehicle/menu/model"):
                return MockResponse(menu_xml([("Prius", "Prius"), ("Prius Prime", "Prius Prime")]))
            if url.endswith("/vehicle/menu/options"):
                self.assertEqual(params["model"], "Prius Prime")
                return MockResponse(menu_xml([("Auto (variable gear ratios), 4 cyl, 2.0 L", "47500")]))
            if url.endswith("/vehicle/47500"):
                return MockResponse(
                    vehicle_xml(
                        fuelType="Regular Gas and Electricity",
                        fuelType1="Regular Gasoline",
                        fuelType2="Electricity",
                        range="550",
                        rangeA="40",
                        comb08="48",
                        VClass="Midsize Cars",
                        model="Prius Prime",
                    )
                )
            if "Find.do" in url:
                return MockResponse(sbs_html(total_range=550, tank_size=10.6))
            raise AssertionError(f"Unexpected URL {url}")

        with patch("vehicle_info.requests.get", side_effect=fake_get):
            result = vehicle_info.get_vehicle_info("2024", "Toyota", "Prius Prime")

        self.assertEqual(result["fuel_type"], "gas")
        self.assertEqual(result["source"], "FuelEconomy.gov")
        self.assertAlmostEqual(result["tank_size"], 10.6, places=1)
        self.assertAlmostEqual(result["range_miles"], 550.0, places=1)

    def test_ev_uses_official_epa_range(self):
        def fake_get(url, params=None, headers=None, timeout=None):
            if url.endswith("/vehicle/menu/make"):
                return MockResponse(menu_xml([("Rivian", "Rivian")]))
            if url.endswith("/vehicle/menu/model"):
                return MockResponse(
                    menu_xml(
                        [
                            ("R1T Dual", "R1T Dual"),
                            ("R1T Tri Max", "R1T Tri Max"),
                        ]
                    )
                )
            if url.endswith("/vehicle/menu/options"):
                if params["model"] == "R1T Dual":
                    return MockResponse(menu_xml([("Automatic (A1)", "47888")]))
                if params["model"] == "R1T Tri Max":
                    return MockResponse(menu_xml([("Automatic (A1)", "48761")]))
                raise AssertionError(f"Unexpected model {params['model']}")
            if url.endswith("/vehicle/47888"):
                return MockResponse(
                    vehicle_xml(
                        atvType="EV",
                        fuelType="Electricity",
                        fuelType1="Electricity",
                        fuelType2="",
                        range="307",
                        rangeCity="322.0",
                        rangeHwy="288.0",
                        VClass="Standard Pickup Trucks",
                        model="R1T",
                    )
                )
            if url.endswith("/vehicle/48761"):
                return MockResponse(
                    vehicle_xml(
                        atvType="EV",
                        fuelType="Electricity",
                        fuelType1="Electricity",
                        fuelType2="",
                        range="371",
                        rangeCity="387.0",
                        rangeHwy="344.0",
                        VClass="Standard Pickup Trucks",
                        model="R1T Tri Max",
                    )
                )
            raise AssertionError(f"Unexpected URL {url}")

        with patch("vehicle_info.requests.get", side_effect=fake_get):
            result = vehicle_info.get_vehicle_info("2025", "Rivian", "R1T")

        self.assertEqual(result["fuel_type"], "electric")
        self.assertEqual(result["source"], "FuelEconomy.gov")
        self.assertEqual(result["matched_model"], "R1T (2 EPA variants)")
        self.assertAlmostEqual(result["range_miles"], 339.0, places=1)

    def test_gas_vehicle_derives_range_from_official_tank_size_when_total_range_is_missing(self):
        def fake_get(url, params=None, headers=None, timeout=None):
            if url.endswith("/vehicle/menu/make"):
                return MockResponse(menu_xml([("Honda", "Honda")]))
            if url.endswith("/vehicle/menu/model"):
                return MockResponse(menu_xml([("Civic", "Civic")]))
            if url.endswith("/vehicle/menu/options"):
                return MockResponse(menu_xml([("Automatic", "12345")]))
            if url.endswith("/vehicle/12345"):
                return MockResponse(
                    vehicle_xml(
                        fuelType="Regular",
                        fuelType1="Regular Gasoline",
                        fuelType2="",
                        range="0",
                        rangeCity="0.0",
                        rangeHwy="0.0",
                        comb08="36",
                        VClass="Compact Cars",
                        model="Civic",
                    )
                )
            if "Find.do" in url:
                return MockResponse(sbs_html(total_range=None, tank_size=12.4))
            raise AssertionError(f"Unexpected URL {url}")

        with patch("vehicle_info.requests.get", side_effect=fake_get):
            result = vehicle_info.get_vehicle_info("2024", "Honda", "Civic")

        self.assertEqual(result["source"], "FuelEconomy-derived")
        self.assertEqual(result["range_source"], "Derived from FuelEconomy MPG and tank size")
        self.assertAlmostEqual(result["tank_size"], 12.4, places=1)
        self.assertAlmostEqual(result["range_miles"], 446.4, places=1)


if __name__ == "__main__":
    unittest.main()
