import ast
with open('roadtrip_planner.py', 'r') as f:
    code = f.read()
try:
    ast.parse(code)
    print('Syntax OK')
except SyntaxError as e:
    print(f'Line {e.lineno}: {e.msg}')
    print(f'Code: {repr(e.text)}')