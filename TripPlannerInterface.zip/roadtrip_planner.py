import os
import tempfile
from urllib.parse import urlencode
import googlemaps
import requests
import tkinter as tk
from tkinter import ttk, scrolledtext
import webbrowser
from gas_price_database import lookup_gas_price
from vehicle_info import get_vehicle_info

# Note: You need to get your own Google Maps API key from https://console.cloud.google.com/
# Set it via environment variable GMAPS_API_KEY or replace the default string.
GMAPS_API_KEY = os.environ.get("GMAPS_API_KEY", "enter_your_google_maps_api_key_here")

# EIA API key for gas prices (free, register at https://www.eia.gov/opendata/register.php)
EIA_API_KEY = os.environ.get("EIA_API_KEY", "enter_your_eia_api_key_here")

# NREL API key for EV charging stations (free, register at https://developer.nrel.gov/signup/)
NREL_API_KEY = os.environ.get("NREL_API_KEY", "enter_your_nrel_api_key_here")

# Function to get route
def get_route(start, end):
    error_msg = ""
    if not GMAPS_API_KEY or GMAPS_API_KEY == "YOUR_GOOGLE_MAPS_API_KEY":
        error_msg = "Error: Google Maps API key is missing or not configured.\nSet the GMAPS_API_KEY environment variable or update GMAPS_API_KEY in the script."
        return None, None, None, None, None, error_msg

    try:
        gmaps = googlemaps.Client(key=GMAPS_API_KEY)
        directions = gmaps.directions(start, end, mode="driving")
    except ValueError as exc:
        error_msg = f"Google Maps API error: {exc}"
        return None, None, None, None, None, error_msg
    except Exception as exc:
        error_msg = f"Error fetching route: {exc}"
        return None, None, None, None, None, error_msg

    if directions:
        route = directions[0]
        distance = route['legs'][0]['distance']['text']
        duration = route['legs'][0]['duration']['text']
        steps = route['legs'][0]['steps']
        overview_polyline = route.get('overview_polyline', {}).get('points')
        bounds = route.get('bounds')
        return distance, duration, steps, overview_polyline, bounds, ""
    return None, None, None, None, None, "No route found."


def build_google_maps_link(start, end, waypoints=None):
    params = {
        "api": 1,
        "origin": start,
        "destination": end,
        "travelmode": "driving",
    }
    if waypoints:
        params["waypoints"] = "|".join(waypoints[:9])
    params = urlencode(params)
    return f"https://www.google.com/maps/dir/?{params}"


def build_static_map_url(start, end, waypoints=None, polyline=None, bounds=None, size="450x320"):
    if not GMAPS_API_KEY or GMAPS_API_KEY == "YOUR_GOOGLE_MAPS_API_KEY":
        return None

    params = [
        ("key", GMAPS_API_KEY),
        ("size", size),
        ("maptype", "roadmap"),
        ("format", "png"),
        ("scale", "2"),
    ]

    # Calculate center and zoom based on bounds if available
    if bounds:
        ne_lat = bounds['northeast']['lat']
        ne_lng = bounds['northeast']['lng']
        sw_lat = bounds['southwest']['lat']
        sw_lng = bounds['southwest']['lng']
        
        center_lat = (ne_lat + sw_lat) / 2
        center_lng = (ne_lng + sw_lng) / 2
        
        # Calculate zoom level based on bounds and map size
        lat_diff = abs(ne_lat - sw_lat)
        lng_diff = abs(ne_lng - sw_lng)
        
        # Use the larger dimension to determine zoom
        max_diff = max(lat_diff, lng_diff)
        
        # Rough calculation for zoom level (this is approximate)
        # For a 450x320 map, these are rough zoom levels - adjusted to zoom out more
        if max_diff > 10:  # Very large area
            zoom = 3
        elif max_diff > 5:  # Large area
            zoom = 4
        elif max_diff > 2:  # Medium area
            zoom = 5
        elif max_diff > 1:  # Small area
            zoom = 6
        elif max_diff > 0.5:  # Local area
            zoom = 7
        elif max_diff > 0.2:  # City area
            zoom = 8
        elif max_diff > 0.1:  # Town area
            zoom = 9
        else:  # Very local
            zoom = 10
            
        params.append(("center", f"{center_lat},{center_lng}"))
        params.append(("zoom", str(zoom)))
    else:
        # Fallback to fixed zoom if no bounds
        params.append(("zoom", "7"))

    markers = [
        f"color:green|label:S|{start}",
        f"color:red|label:D|{end}",
    ]
    if waypoints:
        for idx, waypoint in enumerate(waypoints[:7], start=1):
            markers.append(f"color:blue|label:{idx}|{waypoint}")

    for marker in markers:
        params.append(("markers", marker))

    if polyline:
        params.append(("path", f"color:0x0000ff|weight:4|enc:{polyline}"))
    else:
        path_points = [start]
        if waypoints:
            path_points.extend(waypoints[:7])
        path_points.append(end)
        params.append(("path", "color:0x0000ff|weight:4|" + "|".join(path_points)))

    request = requests.Request("GET", "https://maps.googleapis.com/maps/api/staticmap", params=params).prepare()
    return request.url


def fetch_map_image(url):
    try:
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            return response.content
    except Exception:
        return None
    return None


def extract_price_value(price_text):
    if not price_text or not price_text.startswith("$"):
        return float("inf")
    try:
        return float(price_text.split()[0].replace("$", ""))
    except (TypeError, ValueError):
        return float("inf")

# Function to get gas prices from EIA API
def get_gas_price():
    if not EIA_API_KEY or EIA_API_KEY == "YOUR_EIA_API_KEY":
        return "EIA API key not configured"
    
    try:
        url = "https://api.eia.gov/v1/petroleum/PET_EMP_PTE_NUS_DW/data"
        params = {
            "frequency": "weekly",
            "data[0]": "value",
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "limit": 1,
            "api_key": EIA_API_KEY
        }
        response = requests.get(url, params=params)
        data = response.json()
        if response.status_code != 200:
            if isinstance(data, dict) and 'error' in data:
                message = data['error'].get('message', 'Unknown error')
                return f"Error fetching gas price: {message}"
            return f"Error fetching gas price: HTTP {response.status_code}"

        if isinstance(data, dict) and 'error' in data:
            message = data['error'].get('message', 'Unknown error')
            return f"Error fetching gas price: {message}"

        if 'data' in data and data['data']:
            price = data['data'][0]['value']
            return f"${price} per gallon (national average)"
        else:
            return "Price data not available (EIA returned no data)"
    except Exception as exc:
        return f"Error fetching gas price: {exc}"

# Function to find EV charging stations using NREL API
def find_ev_stations(location, radius=25):
    if not NREL_API_KEY or NREL_API_KEY == "YOUR_NREL_API_KEY":
        return []
    
    try:
        url = "https://developer.nrel.gov/api/alt-fuel-stations/v1/nearest.json"
        params = {
            "api_key": NREL_API_KEY,
            "fuel_type": "ELEC",
            "latitude": location[0],
            "longitude": location[1],
            "radius": radius,
            "limit": 3
        }
        response = requests.get(url, params=params)
        data = response.json()
        if response.status_code != 200:
            message = data.get('error', {}).get('message', response.reason if hasattr(response, 'reason') else 'Unknown error')
            print(f"Error fetching EV stations: HTTP {response.status_code}: {message}")
            return []

        stations = []
        if 'fuel_stations' in data:
            for station in data['fuel_stations']:
                name = station['station_name']
                address = station.get('street_address', 'Address not available')
                price = station.get('ev_pricing', 'Pricing not available')
                stations.append({'name': name, 'address': address, 'price': price})
        else:
            print("Warning: NREL returned no fuel_stations.")
        return stations
    except Exception as exc:
        print(f"Error fetching EV stations: {exc}")
        return []

# Function to find gas stations or charging stations
def find_stations(location, fuel_type, radius=5000):
    if fuel_type == "electric":
        # Parse location string to tuple
        lat, lng = map(float, location.split(','))
        return find_ev_stations((lat, lng), radius=radius/1000)  # convert meters to km
    else:
        # For gas stations, only keep stations we can price from the local database.
        gmaps = googlemaps.Client(key=GMAPS_API_KEY)
        places = gmaps.places(query="gas station", location=location, radius=radius)
        stations = []
        if 'results' in places:
            for result in places['results']:
                name = result['name']
                address = result.get('formatted_address', 'Address not available')
                price = lookup_gas_price(name, address)
                if not price:
                    continue
                stations.append({'name': name, 'address': address, 'price': price})
                if len(stations) == 3:
                    break
        return stations

# Main function
def plan_trip(start, end, year, make, model):
    output = "Road Trip Planner\n\n"
    
    vehicle_data = get_vehicle_info(year, make, model)
    if vehicle_data is None:
        output += "Warning: Could not retrieve vehicle range data from the API or local database.\n"
        fuel_type = "gas"
        vehicle_range_miles = None
    else:
        fuel_type = vehicle_data["fuel_type"]
        vehicle_range_miles = vehicle_data["range_miles"]
        tank_size = vehicle_data.get("tank_size")
        source = vehicle_data.get("source", "unknown")
        output += f"Detected fuel type: {fuel_type} (source: {source})\n"
        if vehicle_range_miles:
            output += f"Estimated vehicle range: {vehicle_range_miles:.0f} miles\n"
        if tank_size:
            output += f"Detected tank size: {tank_size} gallons\n"

    if vehicle_data is None or vehicle_range_miles is None or vehicle_range_miles == 0:
        stop_interval = 200000  # fallback to 200 km if no range is available
    else:
        stop_interval = int(vehicle_range_miles * 1609.34 * 0.8)
        # Removed minimum cap to allow shorter intervals for vehicles with limited range

    if fuel_type not in ("electric", "gas"):
        fuel_type = "gas"

    output += f"Your car fuel type: {fuel_type}\n"
    distance, duration, steps, overview_polyline, bounds, error_msg = get_route(start, end)
    if error_msg:
        output += error_msg + "\n"
        return output, None, None, None
    if not distance:
        output += "Could not find route.\n"
        return output, None, None, None

    output += f"Total distance: {distance}\n"
    output += f"Estimated duration: {duration}\n"
    output += f"Recommended stop interval: {stop_interval / 1609.34:.0f} miles\n\n"

    output += "Recommended stops:\n"
    cumulative_distance = 0
    next_stop_distance = stop_interval
    last_location = None
    recommended_waypoints = []
    for step in steps:
        step_distance = step['distance']['value']  # meters
        cumulative_distance += step_distance
        while cumulative_distance >= next_stop_distance:
            lat = step['end_location']['lat']
            lng = step['end_location']['lng']
            location = f"{lat},{lng}"
            if location != last_location:
                stations = find_stations(location, fuel_type)
                if stations:
                    stations.sort(key=lambda station: extract_price_value(station["price"]))
                    output += f"At approx {next_stop_distance / 1609.34:.0f} miles from the starting point:\n"
                    for station in stations:
                        output += f"  - {station['name']} at {station['address']} (Price: {station['price']})\n"
                    first_stop_address = stations[0]['address']
                    if first_stop_address not in recommended_waypoints:
                        recommended_waypoints.append(first_stop_address)
                    output += "\n"  # Add a blank line between stops
                last_location = location
            next_stop_distance += stop_interval

    maps_link = build_google_maps_link(start, end, recommended_waypoints)
    output += f"Google Maps route link: {maps_link}\n"
    if len(recommended_waypoints) > 9:
        output += "Note: Google Maps links support a limited number of waypoint stops, so only the first 9 recommended stops were included in the link.\n"
    
    return output, maps_link, overview_polyline, bounds

def main():
    print("Road Trip Planner")
    start = input("Enter starting location: ")
    end = input("Enter destination: ")
    year = input("Enter car year: ")
    make = input("Enter car make: ")
    model = input("Enter car model: ")
    
    result, _, _, _ = plan_trip(start, end, year, make, model)
    print(result)

def create_gui():
    root = tk.Tk()
    root.title("Road Trip Planner")
    root.geometry("1000x700")

    # Store the current map link
    map_link_var = tk.StringVar(value="")

    # === Input Frame (Top) ===
    input_frame = ttk.LabelFrame(root, text="Trip Details", padding=10)
    input_frame.pack(fill=tk.X, padx=10, pady=10)

    # First row
    ttk.Label(input_frame, text="Starting Location:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    start_entry = ttk.Entry(input_frame, width=30)
    start_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)

    ttk.Label(input_frame, text="Destination:").grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
    end_entry = ttk.Entry(input_frame, width=30)
    end_entry.grid(row=0, column=3, padx=5, pady=5, sticky=tk.EW)

    # Second row
    ttk.Label(input_frame, text="Car Year:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
    year_entry = ttk.Entry(input_frame, width=30)
    year_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)

    ttk.Label(input_frame, text="Car Make:").grid(row=1, column=2, padx=5, pady=5, sticky=tk.W)
    make_entry = ttk.Entry(input_frame, width=30)
    make_entry.grid(row=1, column=3, padx=5, pady=5, sticky=tk.EW)

    # Third row
    ttk.Label(input_frame, text="Car Model:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
    model_entry = ttk.Entry(input_frame, width=30)
    model_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)

    input_frame.columnconfigure(1, weight=1)
    input_frame.columnconfigure(3, weight=1)

    # === Main Content Frame (Bottom) - Two columns ===
    content_frame = ttk.Frame(root)
    content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # Left side - Output text (equal size)
    left_frame = ttk.LabelFrame(content_frame, text="Trip Results", padding=5)
    left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

    output_text = scrolledtext.ScrolledText(left_frame, width=50, height=40, wrap=tk.WORD)
    output_text.pack(fill=tk.BOTH, expand=True)

    # Right side - Map section (equal size)
    right_frame = ttk.LabelFrame(content_frame, text="Map & Navigation", padding=10)
    right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

    # Map container frame
    map_container = ttk.Frame(right_frame)
    map_container.pack(fill=tk.X, pady=(0, 10))
    map_container.pack_propagate(False)
    map_container.configure(height=250)

    # Map preview label
    map_image_label = tk.Label(map_container, text="Map will appear here", anchor=tk.CENTER, background="#f0f0f0", relief=tk.SOLID)
    map_image_label.pack(fill=tk.BOTH, expand=True)

    map_photo = None

    # Status label
    status_label = tk.Label(right_frame, text="Plan your trip to\ngenerate the map", 
                            font=("Arial", 10), justify=tk.CENTER, fg="gray")
    status_label.pack(pady=(0, 10))

    # Open in Maps button
    def open_map():
        link = map_link_var.get()
        if link:
            webbrowser.open(link)
        else:
            output_text.insert(tk.END, "\n[Info] Plan your trip first to generate a map link.\n")

    # Plan function
    def plan():
        start = start_entry.get()
        end = end_entry.get()
        year = year_entry.get()
        make = make_entry.get()
        model = model_entry.get()

        if not all([start, end, year, make, model]):
            output_text.delete(1.0, tk.END)
            output_text.insert(tk.END, "Please fill in all fields before planning your trip.")
            status_label.config(text="⚠️ Missing fields", fg="red")
            return

        status_label.config(text="Planning...", fg="orange")
        root.update()

        result, maps_link, route_polyline, route_bounds = plan_trip(start, end, year, make, model)
        output_text.delete(1.0, tk.END)
        output_text.insert(tk.END, result)

        if maps_link:
            map_link_var.set(maps_link)

            static_url = build_static_map_url(start, end, polyline=route_polyline, bounds=route_bounds)
            map_image_data = fetch_map_image(static_url) if static_url else None
            if map_image_data:
                try:
                    fd, temp_path = tempfile.mkstemp(suffix='.png')
                    os.close(fd)
                    with open(temp_path, 'wb') as f:
                        f.write(map_image_data)
                    map_photo_obj = tk.PhotoImage(file=temp_path)
                    map_image_label.configure(image=map_photo_obj, text="")
                    map_image_label.image = map_photo_obj
                    map_photo = map_photo_obj
                    os.remove(temp_path)
                except Exception:
                    map_image_label.configure(text="Could not load map preview")
            else:
                map_image_label.configure(text="Map preview unavailable")

            status_label.config(text="✓ Route ready!", fg="green")
        else:
            map_image_label.configure(text="Map preview unavailable")
            status_label.config(text="⚠️ No route found", fg="red")

    map_button = ttk.Button(right_frame, text="Open in Google Maps", command=open_map)
    map_button.pack(pady=(0, 10), fill=tk.X)

    # Plan button (bottom of right frame)
    plan_button = ttk.Button(right_frame, text="Plan Trip", command=plan)
    plan_button.pack(fill=tk.X)

    root.mainloop()

if __name__ == "__main__":
    create_gui()
