import sys
sys.path.append('.')

try:
    import roadtrip_planner
    print('Import successful')
except Exception as e:
    print(f'Import failed: {e}')